function     roi=my_extract_roi(tracks_p,tracks_p_all,id_t,sz)
I=zeros(sz,sz,3);
I(:,:,1)=my_extract_image(tracks_p.x(id_t)',tracks_p.y(id_t)',[sz sz],0.5)
app=zeros(sz);
for k = 1  : length(tracks_p_all)
    k
    app=app | my_extract_image(tracks_p_all(k).x(id_t)',tracks_p_all(k).y(id_t)',[sz sz],0.5);
end
% x1=min(tracks_p.x(id_t));
% y1=min(tracks_p.y(id_t));
% x2=max(tracks_p.x(id_t));
% y2=max(tracks_p.y(id_t));
% I=zeros(round(x2-x1+1),round(y2-y1+1));
% id=sub2ind(size(I),floor(tracks_p.x(id_t)-x1+1),floor(tracks_p.y(id_t)-y1+1));
% I(id)=1;
% I2(:,:,1)=I;
% I2(:,:,2:3)=0;
% 
% for l = 1 : length(tracks_p_all)
% app=zeros(size(I));xt=tracks_p_all(l).x-x1;
% yt=tracks_p_all(l).y-y1;
% id_el=xt<=0 | yt<=0 | xt > size(I,1) | yt>size(I,2);
% xt(id_el)=[];
% yt(id_el)=[];
% app(sub2ind(size(I2),xt,yt))=1;
% I2(:,:,2)=app;
% end

