clear all; 
load('C:\Dati\Sviluppo\EIGENCELLS\track23.mat');
for k = 1 : 7
    data(2*(k-1)+1,:)=p(k).y(50:150);
    data(2*k,:)=p(k).x(50:150);
end
%
save('track23_matrix.mat');

% genero serie a mano
t=1 : 100;
sigma=0.1;
x1=sin(t/100*2*pi)+randn(1,100)*sigma;
x2=sin(t/100*2*pi)+randn(1,100)*sigma;

y=circshift(x1,[0 10])+randn(1,100)*sigma+circshift(x2,[0 10]);
data=[x1;x2;y];
save('prova.mat','data');
%% carico le serie temporali su cui lavorare
% listRealization=dir('C:\Dati\Sviluppo\EIGENCELLS\MuTE\MuTE_onlineVersion\exampleToolbox\track23_matrix.mat'); % matrice dei dati righe serie colonne tempo
listRealization=dir('C:\Dati\Sviluppo\EIGENCELLS\MuTE\MuTE_onlineVersion\exampleToolbox\realization_5000p_1.mat'); % matrice dei dati righe serie colonne tempo
samplingRate         = 1;
channels=1:5;    
autoPairwiseTarDriv  = [1 1 1 1 1 1 1 1]; % significa che per il metodo scelto verrann considerate tutte le coppie X Y e le restanti variabili come condizionanti 
handPairwiseTarDriv  = [0 0 0 0 0 0 0 0]; %?
pointsToDiscard      = 4500; % nessun elemento da eliminre alla fine delle serie
%   neunetnue parameters
    threshold           = 0.008;
    valThreshold        = 0.6;
    numHiddenNodes      = 0.3;
resDir='C:\Dati\Sviluppo\EIGENCELLS\MuTE\MuTE_onlineVersion\exampleToolbox\results\';
copyDir   = [resDir 'entropyMatrices\'];
if (~exist([resDir 'copyDir'],'dir'))
    mkdir(copyDir);
end
dataDir=pwd;
% idtarget= [1   2   3   4   5   6   7   8   9   10   11   12   13   14];
% idDrivers=[3   4   5   6   7   8   9   10  11  12   13    14   1    2 ;
%            5   6   7   8   9   10  11  12  13  14   1      2   3    4;
%            7   8   9  10   11  12  13  14  1   2    3      4   5    6;
%            9  10  11  12   13  14  1   2   3   4    5      6   7    8;
numProcessors               = 0; % no parallel processing
    [output1,params1]               = parametersAndMethods(listRealization,samplingRate,pointsToDiscard,channels,autoPairwiseTarDriv,...
                                      handPairwiseTarDriv,resDir,dataDir,copyDir,numProcessors,...
                                       'linue',[],[],[],5,'multiv',5,5,'bayesian',@linearEntropy,[1 0],[1 1],@generateConditionalTerm,0);

