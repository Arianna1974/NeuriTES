function [y]=identity(x,varargin)

y=x;
return;
