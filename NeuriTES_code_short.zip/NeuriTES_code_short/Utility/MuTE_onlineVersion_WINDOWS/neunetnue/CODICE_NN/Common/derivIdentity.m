function [dId]=derivIdentity(x)
% [dId]=derivIdentity(x)

dId = ones(size(x));

return;