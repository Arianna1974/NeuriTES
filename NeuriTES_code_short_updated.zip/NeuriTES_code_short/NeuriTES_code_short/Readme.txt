Unzip the NEURITES_code directory

The main file is: NEURITES_main.m


%%
The NEURITES code is composed by two distinct blocks: 

the first one calculates the ASS and save on the disk the segmented frames
the second one extract the morphological descriptors, the TE-f, and performs classification

The frames and related GT in training are in name\Train_frames and name\GT_Train_frames
The frames for test are in name\Test_frames 
The segmented frames will be written in name\GT_Test_frames

%%%%%%%%%ASS computation

file: NEURITES_main_ASS.m 

receives in input the 
- train_directory where are the frame in training and the corresponding GT frames for the training of the 
semantic segmentation net 
- test_directory where the frames to be segmented are

The segmented frames are saved in tif format in a pre-created directory '%\GT_Test_Frames'


%%%%%%%%%Morphological descriptors extraction

file: NEURITES_main_moto_characterization.m
receives in input 
- a file with Moto_coordinates.mat that contains a structure my_table with info for each moto neuron, i.e. name, diagnosis, time of colture, etc.
- the directory of the frames and related segmentation images

produces in output
- a file Results_moto_SS.mat containing a structure moto with fields:			
     label (diagnosis, name, position of the motor neuron)
     par (descriptors matrix, time X n. descriptors)
     mask 
     frames

%%%%%%%%%TE descriptor extraction

file: NEURITES_main_TE_analysis.m
receives in input
- Results_moto_SS.mat
produces in output
- Data_te_SS.mat  containing the TE descriptors and related labels

%%%%%%%%%Classification

file: NEURITES_main_classification_SS.m
receives in input
- Data_te_SS.mat
produces in output
- Classification_results.mat

with confusion matrices, accuracy values, AUC values of individual descriptors.


%%%%%%%%%Data Availability

Supplementary data are available at:
https://zenodo.org/records/10119236

