clear all; close all; clc;
load('Data_te_SS.mat');
% AUC par_TE

% moto 57
par_te_57=par_te(gt_day==0,:);
gt_moto_57=gt_moto(gt_day==0);

% moto 79
par_te_79=par_te(gt_day==1,:);
gt_moto_79=gt_moto(gt_day==1);

% AUC 57
% AUC par_te
for k = 1 : size(par_te_57,2)
    k
    [X,Y,th,AUC_te_57(k)]=perfcurve(gt_moto_57,par_te_57(:,k),1);
end

% AUC 79
% AUC par_te
for k = 1 : size(par_te_79,2)
    k
    [X,Y,th,AUC_te_79(k)]=perfcurve(gt_moto_79,par_te_79(:,k),1);
end

%% CLASSIFICAZIONE TE
%% 57 
% leave one motoneuron out
id_sel_te_57=find(AUC_te_57>0.68 | AUC_te_57<0.33);
[idx_57,idy_57]=ind2sub([21 21],id_sel_te_57); % per vedere quali implicazioni sono importanti

for k = 1 : length(gt_moto_57)
    k
   train=true(1,length(gt_moto_57));
   train(k)=false;
   test=not(train);
   [score_te_57(k),class_te_57(k)]=my_class(train,test,par_te_57,gt_moto_57,id_sel_te_57);
end

C_te_57=confusionmat(gt_moto_57,class_te_57);
ACC_te_57=(C_te_57(1,1)/sum(C_te_57(1,:))+C_te_57(2,2)/sum(C_te_57(2,:)))/2

%% CLASSIFICAZIONE TE
%% 79 
% leave one motoneuron out
id_sel_te_79=find(AUC_te_79>0.7 | AUC_te_79<0.3);
[idx_79,idy_79]=ind2sub([21 21],id_sel_te_79); % per vedere quali implicazioni sono importanti

for k = 1 : length(gt_moto_79)
    k
   train=true(1,length(gt_moto_79));
   train(k)=false;
   test=not(train);
   [score_te_79(k),class_te_79(k)]=my_class(train,test,par_te_79,gt_moto_79,id_sel_te_79);
end

C_te_79=confusionmat(gt_moto_79,class_te_79);
ACC_te_79=(C_te_79(1,1)/sum(C_te_79(1,:))+C_te_79(2,2)/sum(C_te_79(2,:)))/2

save('Classification_result.mat');




