% NEURITES MAIN FILE
% see Readme.txt file included in this tool
%% create directory where segmented frames are %\GT_Test_Frames

%% addpath to utilities of NEURITES
addpath(genpath('%\NEURITES\Utility\'));

%% BLOCK 1
% receives in input the 
% - train_directory where are the frame in training and the corresponding GT frames for the training of the 
% semantic segmentation net 
% - test_directory where the frames to be segmented are
% 
% The segmented frames are saved in tif format in a pre-created directory '%\GT_Test_Frames'

NEURITES_main_ASS

%% BLOCK 2
% morphological descriptors extraction

% receives in input 
% - a file Moto_coordinates.mat that contains a structure my_table with info for each moto neuron, i.e. name, diagnosis, time of colture, etc.
% - the directory of the frames and related segmentation images
% 
% produces in output
% - a file Results_moto_SS.mat containing a structure moto with fields:			
%      label (diagnosis, name, position of the motor neuron)
%      par (descriptors matrix, time X n. descriptors)
%      mask 
%      frames

NEURITES_main_moto_characterization.m

%% BLOCK 2
% TE descriptor extraction

% receives in input
% - Results_moto_SS.mat
% produces in output
% - Data_te_SS.mat containing the TE descriptors and related labels

NEURITES_main_TE_analysis.m

%% BLOCK2
% Classification

% receives in input
% - Data_te_SS.mat
% produces in output
% - Classification_results.mat
% 
% with confusion matrices, accuracy values, AUC values of individual descriptors.

NEURITES_main_classification_SS.m