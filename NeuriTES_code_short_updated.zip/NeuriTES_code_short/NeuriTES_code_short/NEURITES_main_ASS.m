% Semantic segmentation 
close all; clc;
name=XXX; % main directory 
% you MUST create the directory in output name\Test_Frames and name\GT_Test_Frames
dir_data=name;
%%
% load datastore with frame and segmented shape
imds = imageDatastore([dir_data,'\Train_Frames\'],'ReadFcn',@(x) my_read(x)); % link frame di addestramento
pxds = pixelLabelDatastore([name,'\GT_Train_Frames\'],["N" "B"],[0 255]); % link immagini di GT
%0=N e 1=B

%% Addestamento RES-NET50
numClasses=2;
% image dimension 
imageSize=[400 400 3];

% data augmentation
augmenter = imageDataAugmenter('RandRotation',[0 360],'RandXReflection',true,'RandXTranslation',[-10 10],'RandYTranslation',[-10 10]);
pximds = pixelLabelImageDatastore(imds,pxds,'DataAugmentation',augmenter,'OutputSize',imageSize,'ColorPreprocessing','gray2rgb');

% semantuc segmentation net
lgraph = deeplabv3plusLayers(imageSize, numClasses, "resnet50");
tbl = countEachLabel(pximds);
totalNumberOfPixels = sum(tbl.PixelCount);
frequency = tbl.PixelCount / totalNumberOfPixels;
classWeights = 1./frequency;

pxLayer = pixelClassificationLayer('Name','labels','Classes',tbl.Name,'ClassWeights',classWeights);
lgraph = replaceLayer(lgraph,"classification",pxLayer);

%training net
options = trainingOptions('sgdm', ...
    'MaxEpochs',30, ...  
    'MiniBatchSize',8, ...
    'Plots','training-progress','ExecutionEnvironment' ,'multi-gpu');
net = trainNetwork(pximds,lgraph,options);

%% ASS writing results in tif on the disk
f_test=dir([dir_data,'\Test_Frames\*.tif']);
n=1;
for k = 1 : length(f_test)
    [k length(f_test)]
    testImage=my_read([dir_data,'\Test_Frames\',f_test(k).name]);
    name=f_test(k).name(1:11); 
    testImage=imresize(testImage,[400 400],'bilinear');
    C_test= semanticseg(testImage,net);
     D=C_test=='B';
     D=bwareafilt(D,1);
     roi_test(:,:,n)=D;
     flag(k)=false;
     if k>=2 && strcmp(name,f_test(k-1).name(1:11)) % sono nello stesso motoneurone
        FM=evaluation_segmentation(roi_test(:,:,n-1),D);
        if FM<0.8 
         D_bis=my_adapt(testImage,net,roi_test(:,:,n-1));
         roi_test(:,:,n)=D_bis;
         flag(k)=true;
        else
        end
     else
     clear roi_test ; 
     n=1;
     roi_test(:,:,n)=D;
     end
     imwrite(roi_test(:,:,n),[dir_data,'\GT_Test_Frames\',f_test(k).name(1:end-4),'_seg.tif']);
     n=n+1;
     clear D_bis D C_test;
end

