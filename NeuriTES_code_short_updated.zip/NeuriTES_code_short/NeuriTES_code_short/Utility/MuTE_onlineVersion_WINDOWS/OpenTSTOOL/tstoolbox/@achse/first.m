function f = first(a)

f = a.first;
