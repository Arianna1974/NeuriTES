function len = length(l)


%tstoolbox/@list/length
%   Syntax:
%     * len = length(l)
%
%   returns the number of strings in list l.
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt

len = l.len;
