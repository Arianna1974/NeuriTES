function c = char(l)

%tstoolbox/@list/char
%   returns a char array from list l.
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt

c = char(l.data);
