function n = label(d)
%tstoolbox/@description/label
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt



n = d.label;
