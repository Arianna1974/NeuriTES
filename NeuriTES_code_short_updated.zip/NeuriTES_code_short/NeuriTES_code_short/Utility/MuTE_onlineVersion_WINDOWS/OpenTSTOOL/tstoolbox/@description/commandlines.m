function c = commandlines(d)
%tstoolbox/@description/commandlines
%
% Copyright 1997-2001 DPI Goettingen, License http://www.physik3.gwdg.de/tstool/gpl.txt





% C.Merkwirth,U.Parlitz,W.Lauterborn  DPI Goettingen 1998

error(nargchk(1,1,nargin));

c = d.commandlines;
