function [Y]=sigmoid(X)

%Y = 1 ./ (1 + exp(-X));

Y = 1 ./ (1 + exp(-X));

return;
