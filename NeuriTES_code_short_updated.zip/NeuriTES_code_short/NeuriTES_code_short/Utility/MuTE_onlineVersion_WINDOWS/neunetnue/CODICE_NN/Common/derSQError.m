function der=derSQError(output,target)
% function [der]=derSQError(output,target)

der=(output-target);

return;