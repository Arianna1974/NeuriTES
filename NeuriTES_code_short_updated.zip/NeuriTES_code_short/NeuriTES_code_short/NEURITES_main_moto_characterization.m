%% moto structure construction containing time-varying descriptors
% STEP1. Extraction of moto coordinates from Moto_corodinates
% STEP2. Extraction of ROI from coordinates and frames in the directory
% STEP3. Calculation of 21 descriptors from the segmented shape and the
% corresponding frame
% this code serve for the simultaneously characterization of comparative
% experiments, but can be used also for one experiment, it depends on te
% my_table variable
clear all; close all;
load('Moto_coordinates.mat');
f79=dir('79_SS\GT_Test_frames\*.tif');
f57=dir('57_SS\GT_Test_frames\*.tif');
im79=dir('79_SS\Test_frames\*.tif');
im57=dir('57_SS\Test_frames\*.tif');
for k = 1 : size(my_table,1) 
    time=my_table{k,1};
    name=my_table{k,2};
    num=my_table{k,3};
    c=my_table{k,4};
    if strcmp(time,'79')
        n=[];
        for l = 1 : length(f79)
            if strcmp(f79(l).name(1:8),name) && str2double(f79(l).name(10:11))==num
                n=[n l];
            end
        end
        f_sel=f79(n);
    elseif strcmp(time,'57')
        n=[];
        for l = 1 : length(f57)
            if strcmp(f57(l).name(1:8),name) && str2double(f57(l).name(10:11))==num
                n=[n l];
            end
        end
        f_sel=f57(n);
    else
    end
    info=my_table(k,:);
    moto(k).label=my_label(info);
    for j = 1 : length(f_sel)
        [k size(my_table,1) j  length(f_sel)]
        gt=im2double(imread([f_sel(j).folder,'\',f_sel(j).name]));
        roi=imresize(im2double(my_read([f_sel(j).folder(1:end-14),f_sel(j).folder(end-10:end),'\',f_sel(j).name(1:end-8),'.tif'])),[400 400],'bilinear');
        % descriptos extractiom
        par=my_descriptors(gt,roi);
        moto(k).par(j,:)=par;
        moto(k).mask(j).vec=find(gt);
        moto(k).frame(j)=j;
    end
end


save('Result_moto_SS.mat','moto');
