%% Transfer Entropy calculation
clear all; close all; clc;
load('Result_moto_SS.mat');
T1=30; % smoothing of descriptors along time
T=274; % duration of the time series to analyze (1:T)
par_full=[];
gt_full=[];
gt_day_full=[];
time_full=[];
gt_moto_full=[];
% directory where the MUTE toolbox is,
% e.g.  %\MuTE_onlineVersion_WINDOWS\exampleToolbox\
name=XXX;

for k = 1 : length(moto)
    k
sprintf('Moto time:%s - healthy %d...',moto(k).label.t,moto(k).label.safe)
   app=moto(k).par(1:T,:);
   for l = 1 : size(app,2)
   app2(:,l)=smooth(app(:,l),T1,'moving');
   end
   % features smoothed in time
   data=app2';
   clear app2 app;
   save([name,'\prova2.mat'],'data');
   [a,b]=my_te(1:size(data,1),'linue',name);
   A=a.meanRes;
   par_te(k,:)=A(:);
   gt_moto(k)=moto(k).label.safe;
   day=strcmp(moto(k).label.t,'79');
   gt_day(k)=day;
   clear day A a b C C_triu;
end
% saving data to a mat file
save('Data_te_SS.mat');
